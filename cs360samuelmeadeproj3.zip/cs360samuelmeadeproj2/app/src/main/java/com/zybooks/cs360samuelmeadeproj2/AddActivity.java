package com.zybooks.cs360samuelmeadeproj2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class AddActivity extends AppCompatActivity {

    EditText weight_input, date_input;
    Button addWeight;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        weight_input = findViewById(R.id.curWeight);
        date_input = findViewById(R.id.date);
        addWeight = findViewById(R.id.addWeightButton);

        addWeight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GraphDBHelper myDB = new GraphDBHelper(AddActivity.this);
                myDB.addWeight(Integer.valueOf(weight_input.getText().toString().trim()),
                        date_input.getText().toString().trim());
            }
        });

    }
}
package com.zybooks.cs360samuelmeadeproj2;

import android.content.Intent;
import android.database.Cursor;
import android.database.DatabaseErrorHandler;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class DashboardActivity extends AppCompatActivity {
    DBHelper GraphDB;
    EditText currentWeight;
    TextView goalWeight, share;
    TextView message;
    RecyclerView recyclerView;
    FloatingActionButton addEvent;
    GraphDBHelper myDB;
    ArrayList<String> entry_id, weight, date;

    CustomAdapter customAdapter;


    @Override
    protected void onCreate(Bundle savedInstance) {
        super.onCreate(savedInstance);
        setContentView(R.layout.activity_dashboard);

        recyclerView = findViewById(R.id.recyclerview);
        addEvent = findViewById(R.id.addButton);

        addEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(DashboardActivity.this, AddActivity.class);
                startActivity(intent);
            }
        });

        share = findViewById(R.id.share);
        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        myDB = new GraphDBHelper(DashboardActivity.this);
        entry_id = new ArrayList<>();
        weight = new ArrayList<>();
        date = new ArrayList<>();

        storeDataInArrays();
        customAdapter = new CustomAdapter(DashboardActivity.this, entry_id, weight, date);
        recyclerView.setAdapter(customAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(DashboardActivity.this));
    }

    void storeDataInArrays() {
        Cursor cursor = myDB.readAllData();
        if (cursor.getCount() == 0) {
            Toast.makeText(this, "No Data", Toast.LENGTH_SHORT).show();
        } else {
            while (cursor.moveToNext()) {
                entry_id.add(cursor.getString(0));
                weight.add(cursor.getString(1));
                date.add(cursor.getString(2));

            }
        }
    }
}

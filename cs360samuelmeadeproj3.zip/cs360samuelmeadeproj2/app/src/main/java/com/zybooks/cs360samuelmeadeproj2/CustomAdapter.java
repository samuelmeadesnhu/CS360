package com.zybooks.cs360samuelmeadeproj2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.MyViewHolder> {

    private Context context;
    private ArrayList entry_id, weight, date;

    CustomAdapter(Context context, ArrayList entry_id, ArrayList weight, ArrayList date) {
        this.context = context;
        this.entry_id = entry_id;
        this.weight = weight;
        this.date = date;
    }

    @NonNull
    @Override
    public CustomAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.my_row, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CustomAdapter.MyViewHolder holder, int position) {
        holder.entry_id_txt.setText(String.valueOf(entry_id.get(position)));
        holder.weight_txt.setText(String.valueOf(weight.get(position)));
        holder.date_txt.setText(String.valueOf(date.get(position)));
    }

    @Override
    public int getItemCount() {
        return 0;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView entry_id_txt, weight_txt, date_txt;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            entry_id_txt = itemView.findViewById(R.id.entry_id_txt);
            weight_txt = itemView.findViewById(R.id.weight_txt);
            date_txt = itemView.findViewById(R.id.date_txt);
        }
    }
}